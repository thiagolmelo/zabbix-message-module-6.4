<?php

namespace Modules\MessageOfTheDay;

use Zabbix\Core\CModule,
    APP,
    CMenuItem,
    CWebUser,
    DB;

class Module extends CModule {

    const MACRO_NAME = '{$MOTD_CONFIG}';

    public function init(): void {
        APP::Component()->get('menu.main')
            ->findOrAdd(_('Administration'))
                ->getSubmenu()
                    ->add((new CMenuItem(_('Message of the Day')))
                        ->setAction('messageoftheday.edit')
                    );

        $config = self::loadConfig();

        if ($config['enabled'] && !empty($config['message'])) {
            $user_type = CWebUser::getType();
            $show = ($config['show_to'] === 'all')
                || ($config['show_to'] === 'admins' && $user_type >= USER_TYPE_ZABBIX_ADMIN);

            if ($show) {
                $js_config = json_encode([
                    'enabled'        => true,
                    'message'        => $config['message'],
                    'type'           => $config['type'],
                    'dismissible'    => (bool) $config['dismissible'],
                    'link_url'       => $config['link_url'] ?? '',
                    'link_label'     => !empty($config['link_label']) ? $config['link_label'] : 'Read more',
                    'font_size'      => $config['font_size'] ?? 13,
                    'font_bold'      => (bool) ($config['font_bold'] ?? false),
                    'font_italic'    => (bool) ($config['font_italic'] ?? false),
                    'font_underline' => (bool) ($config['font_underline'] ?? false),
                    'font_color'     => $config['font_color'] ?? ''
                ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);

                zbx_add_post_js('window.MOTD_CONFIG = ' . $js_config . ';');
            }
        }
    }

    public static function loadConfig(): array {
        $defaults = [
            'enabled'        => false,
            'message'        => '',
            'type'           => 'info',
            'dismissible'    => true,
            'show_to'        => 'all',
            'link_url'       => '',
            'link_label'     => 'Read more',
            'font_size'      => 13,
            'font_bold'      => false,
            'font_italic'    => false,
            'font_underline' => false,
            'font_color'     => ''
        ];

        try {
            $rows = DB::select('globalmacro', [
                'output' => ['value'],
                'filter' => ['macro' => self::MACRO_NAME]
            ]);

            if ($rows) {
                $data = json_decode($rows[0]['value'], true);
                if (is_array($data)) {
                    return array_merge($defaults, $data);
                }
            }
        } catch (\Exception $e) {}

        return $defaults;
    }

    public static function saveConfig(array $config): bool {
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        try {
            $existing = DB::select('globalmacro', [
                'output' => ['globalmacroid'],
                'filter' => ['macro' => self::MACRO_NAME]
            ]);

            if ($existing) {
                DB::update('globalmacro', [
                    'values' => ['value' => $json],
                    'where'  => ['macro' => self::MACRO_NAME]
                ]);
            } else {
                DB::insert('globalmacro', [[
                    'macro'       => self::MACRO_NAME,
                    'value'       => $json,
                    'description' => 'Message of the Day module configuration. Do not edit manually.',
                    'type'        => 0
                ]]);
            }

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}
