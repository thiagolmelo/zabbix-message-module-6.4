<?php

namespace Modules\MessageOfTheDay\Actions;

use CController,
    CControllerResponseRedirect,
    CUrl,
    CWebUser,
    Modules\MessageOfTheDay\Module;

class MessageOfTheDaySave extends CController {

    public function init(): void {
        $this->disableCsrfValidation();
    }

    protected function checkInput(): bool {
        $fields = [
            'enabled'        => 'in 0,1',
            'message'        => 'string',
            'type'           => 'in info,warning,danger,success',
            'dismissible'    => 'in 0,1',
            'show_to'        => 'in all,admins',
            'link_url'       => 'string',
            'link_label'     => 'string',
            'font_size'      => 'int32',
            'font_bold'      => 'in 0,1',
            'font_italic'    => 'in 0,1',
            'font_underline' => 'in 0,1',
            'font_color'     => 'string'
        ];

        $ret = $this->validateInput($fields);

        if (!$ret) {
            $this->setResponse(new CControllerResponseRedirect(
                (new CUrl('zabbix.php'))
                    ->setArgument('action', 'messageoftheday.edit')
                    ->setArgument('saved', '0')
                    ->getUrl()
            ));
        }

        return $ret;
    }

    protected function checkPermissions(): bool {
        return (CWebUser::getType() == USER_TYPE_SUPER_ADMIN);
    }

    protected function doAction(): void {
        $link_url = trim($this->getInput('link_url', ''));
        if ($link_url !== '' && !preg_match('/^https?:\/\//i', $link_url)) {
            $link_url = 'https://' . $link_url;
        }

        // Sanitize color: only allow valid hex colors
        $font_color = trim($this->getInput('font_color', ''));
        if ($font_color !== '' && !preg_match('/^#[0-9a-fA-F]{3,6}$/', $font_color)) {
            $font_color = '';
        }

        // Clamp font size between 10 and 48
        $font_size = (int) $this->getInput('font_size', 13);
        $font_size = max(10, min(48, $font_size));

        $config = [
            'enabled'        => (bool) $this->getInput('enabled', 0),
            'message'        => $this->getInput('message', ''),
            'type'           => $this->getInput('type', 'info'),
            'dismissible'    => (bool) $this->getInput('dismissible', 1),
            'show_to'        => $this->getInput('show_to', 'all'),
            'link_url'       => $link_url,
            'link_label'     => trim($this->getInput('link_label', 'Read more')) ?: 'Read more',
            'font_size'      => $font_size,
            'font_bold'      => (bool) $this->getInput('font_bold', 0),
            'font_italic'    => (bool) $this->getInput('font_italic', 0),
            'font_underline' => (bool) $this->getInput('font_underline', 0),
            'font_color'     => $font_color
        ];

        $success = Module::saveConfig($config);

        $this->setResponse(new CControllerResponseRedirect(
            (new CUrl('zabbix.php'))
                ->setArgument('action', 'messageoftheday.edit')
                ->setArgument('saved', $success ? '1' : '0')
                ->getUrl()
        ));
    }
}
