<?php

/**
 * @var array $data
 */

$form = (new CForm('post', 'zabbix.php'))
    ->addVar('action', 'messageoftheday.save')
    ->setName('messageoftheday_form');

if (array_key_exists('saved', $_GET)) {
    if ($_GET['saved'] === '1') {
        $form->addItem(
            (new CDiv(_('Configuration saved successfully. All frontend nodes will reflect the change immediately.')))
                ->addClass(ZBX_STYLE_MSG_GOOD)
                ->addStyle('margin-bottom: 8px; padding: 8px 12px;')
        );
    } else {
        $form->addItem(
            (new CDiv(_('Failed to save configuration. Check database permissions.')))
                ->addClass(ZBX_STYLE_MSG_BAD)
                ->addStyle('margin-bottom: 8px; padding: 8px 12px;')
        );
    }
}

// ---- Tab 1: Banner settings ----
$tab_banner = (new CFormList())
    ->addRow(
        (new CLabel(_('Enabled'), 'enabled')),
        (new CCheckBox('enabled', 1))->setChecked($data['enabled'])
    )
    ->addRow(
        (new CLabel(_('Message'), 'message'))->setAsteriskMark(),
        (new CTextArea('message', $data['message']))
            ->setWidth(ZBX_TEXTAREA_STANDARD_WIDTH)
            ->setAttribute('rows', 3)
            ->setAttribute('maxlength', 2048)
    )
    ->addRow(
        (new CLabel(_('Banner type'), 'type')),
        (new CSelect('type'))
            ->setFocusableElementId('type')
            ->addOptions(CSelect::createOptionsFromArray([
                'info'    => _('Information (blue)'),
                'warning' => _('Warning (yellow)'),
                'danger'  => _('Critical (red)'),
                'success' => _('Success (green)')
            ]))
            ->setValue($data['type'])
    )
    ->addRow(
        (new CLabel(_('Dismissible'), 'dismissible')),
        (new CCheckBox('dismissible', 1))->setChecked($data['dismissible'])
    )
    ->addRow(
        (new CLabel(_('Show to'), 'show_to')),
        (new CSelect('show_to'))
            ->setFocusableElementId('show_to')
            ->addOptions(CSelect::createOptionsFromArray([
                'all'    => _('All users'),
                'admins' => _('Administrators only')
            ]))
            ->setValue($data['show_to'])
    )
    ->addRow(
        (new CLabel(_('Link URL'), 'link_url')),
        (new CTextBox('link_url', $data['link_url']))
            ->setWidth(ZBX_TEXTAREA_STANDARD_WIDTH)
            ->setAttribute('placeholder', 'https://example.com/more-info')
            ->setAttribute('maxlength', 2048)
    )
    ->addRow(
        (new CLabel(_('Link label'), 'link_label')),
        (new CTextBox('link_label', $data['link_label']))
            ->setWidth(ZBX_TEXTAREA_MEDIUM_WIDTH)
            ->setAttribute('placeholder', 'Read more')
            ->setAttribute('maxlength', 100)
    );

// ---- Tab 2: Text style ----
$style_controls = (new CDiv())
    ->addStyle('display: flex; align-items: center; gap: 12px; flex-wrap: wrap;');

// Bold
$style_controls->addItem(
    (new CLabel(
        [
            (new CCheckBox('font_bold', 1))->setChecked($data['font_bold']),
            ' ', _('Bold')
        ],
        'font_bold'
    ))->addStyle('font-weight: bold; cursor: pointer;')
);

// Italic
$style_controls->addItem(
    (new CLabel(
        [
            (new CCheckBox('font_italic', 1))->setChecked($data['font_italic']),
            ' ', _('Italic')
        ],
        'font_italic'
    ))->addStyle('font-style: italic; cursor: pointer;')
);

// Underline
$style_controls->addItem(
    (new CLabel(
        [
            (new CCheckBox('font_underline', 1))->setChecked($data['font_underline']),
            ' ', _('Underline')
        ],
        'font_underline'
    ))->addStyle('text-decoration: underline; cursor: pointer;')
);

// Font size
$size_wrap = (new CDiv())
    ->addStyle('display: flex; align-items: center; gap: 6px;');
$size_wrap->addItem((new CLabel(_('Size'), 'font_size')));
$size_wrap->addItem(
    (new CNumericBox('font_size', $data['font_size'], 2))
        ->setWidth(60)
        ->setAttribute('min', 10)
        ->setAttribute('max', 48)
);
$size_wrap->addItem((new CSpan('px'))->addStyle('color: #999;'));
$style_controls->addItem($size_wrap);

// Color picker
$color_wrap = (new CDiv())
    ->addStyle('display: flex; align-items: center; gap: 6px;');
$color_wrap->addItem((new CLabel(_('Color'), 'font_color')));
$color_val = htmlspecialchars($data['font_color'] ?: '#333333');
$color_wrap->addItem(
    (new CDiv())
        ->addItem(
            (new CTag('input', false))
                ->setAttribute('type', 'color')
                ->setAttribute('id', 'font_color_picker')
                ->setAttribute('value', $data['font_color'] ?: '#333333')
                ->addStyle('width: 40px; height: 28px; border: 1px solid #ccc; border-radius: 3px; cursor: pointer; padding: 1px;')
        )
);
$color_wrap->addItem(
    (new CTextBox('font_color', $data['font_color']))
        ->setAttribute('id', 'font_color_text')
        ->setAttribute('placeholder', 'default')
        ->setAttribute('maxlength', 7)
        ->setWidth(90)
);
$color_wrap->addItem(
    (new CButton('font_color_reset', _('Reset')))
        ->setAttribute('type', 'button')
        ->setAttribute('id', 'font_color_reset')
        ->addClass(ZBX_STYLE_BTN_ALT)
);
$style_controls->addItem($color_wrap);

// Live preview box
$preview_msg = htmlspecialchars($data['message'] ?: 'Your message preview will appear here.');
$preview_style = 'padding: 12px 20px; border-radius: 4px; margin-top: 16px; text-align: center; background: #dbeafe; border-left: 5px solid #2563eb; color: #1e3a5f;';

$preview = (new CDiv())
    ->addItem(
        (new CDiv(_('Preview')))
            ->addStyle('font-size: 11px; color: #999; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.05em;')
    )
    ->addItem(
        (new CDiv())
            ->setAttribute('id', 'motd_preview')
            ->addStyle($preview_style)
    );

$tab_style = (new CFormList())
    ->addRow(
        (new CLabel(_('Text style'))),
        $style_controls
    )
    ->addRow('', $preview);

// ---- Assemble tabs ----
$form->addItem(
    (new CTabView())
        ->addTab('tab_banner', _('Banner settings'), $tab_banner)
        ->addTab('tab_style',  _('Text style'),      $tab_style)
);

$form->addItem(
    (new CFormActions())
        ->addItem(new CSubmit('update', _('Update')))
);

// ---- Inline JS for live preview + color picker sync ----
$form->addItem(new CTag('script', true, "
(function() {
    function updatePreview() {
        var msg      = document.querySelector('[name=message]');
        var bold     = document.querySelector('[name=font_bold]');
        var italic   = document.querySelector('[name=font_italic]');
        var under    = document.querySelector('[name=font_underline]');
        var size     = document.querySelector('[name=font_size]');
        var colorTxt = document.getElementById('font_color_text');
        var type     = document.querySelector('[name=type]');
        var preview  = document.getElementById('motd_preview');
        if (!preview) return;

        var colors = {
            info:    { bg: '#dbeafe', border: '#2563eb', color: '#1e3a5f' },
            warning: { bg: '#fef9c3', border: '#ca8a04', color: '#713f12' },
            danger:  { bg: '#fee2e2', border: '#dc2626', color: '#7f1d1d' },
            success: { bg: '#dcfce7', border: '#16a34a', color: '#14532d' }
        };

        var t = type ? (type.value || 'info') : 'info';
        var c = colors[t] || colors.info;
        var fc = colorTxt && colorTxt.value.match(/^#[0-9a-fA-F]{3,6}$/) ? colorTxt.value : c.color;

        preview.style.background   = c.bg;
        preview.style.borderLeft   = '5px solid ' + c.border;
        preview.style.color        = fc;
        preview.style.fontWeight   = (bold && bold.checked)   ? 'bold'      : 'normal';
        preview.style.fontStyle    = (italic && italic.checked) ? 'italic'  : 'normal';
        preview.style.textDecoration = (under && under.checked) ? 'underline' : 'none';
        preview.style.fontSize     = (size && size.value) ? size.value + 'px' : '13px';
        preview.textContent        = (msg && msg.value) ? msg.value : 'Your message preview will appear here.';
    }

    // Sync color picker <-> text input
    var picker = document.getElementById('font_color_picker');
    var txtCol = document.getElementById('font_color_text');
    var resetBtn = document.getElementById('font_color_reset');

    if (picker && txtCol) {
        picker.addEventListener('input', function() {
            txtCol.value = picker.value;
            updatePreview();
        });
        txtCol.addEventListener('input', function() {
            if (txtCol.value.match(/^#[0-9a-fA-F]{3,6}$/)) {
                picker.value = txtCol.value;
            }
            updatePreview();
        });
    }

    if (resetBtn && txtCol && picker) {
        resetBtn.addEventListener('click', function() {
            txtCol.value = '';
            picker.value = '#333333';
            updatePreview();
        });
    }

    // Attach all other inputs
    var inputs = document.querySelectorAll('[name=message],[name=type],[name=font_bold],[name=font_italic],[name=font_underline],[name=font_size]');
    for (var i = 0; i < inputs.length; i++) {
        inputs[i].addEventListener('change', updatePreview);
        inputs[i].addEventListener('input', updatePreview);
    }

    updatePreview();
})();
"));

(new CHtmlPage())
    ->setTitle(_('Message of the Day'))
    ->setDocUrl('')
    ->addItem(
        (new CDiv(_('Configuration is stored in the Zabbix database and shared across all frontend nodes.')))
            ->addStyle('color: #999; font-size: 12px; margin-bottom: 12px;')
    )
    ->addItem($form)
    ->show();
