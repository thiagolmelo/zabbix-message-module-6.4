<?php

namespace Modules\MessageOfTheDay\Actions;

use CController,
    CControllerResponseData,
    CWebUser,
    Modules\MessageOfTheDay\Module;

class MessageOfTheDayEdit extends CController {

    public function init(): void {
        $this->disableCsrfValidation();
    }

    protected function checkInput(): bool {
        return true;
    }

    protected function checkPermissions(): bool {
        return (CWebUser::getType() == USER_TYPE_SUPER_ADMIN);
    }

    protected function doAction(): void {
        $config = Module::loadConfig();

        $response = new CControllerResponseData([
            'enabled'      => (bool) $config['enabled'],
            'message'      => $config['message'],
            'type'         => $config['type'],
            'dismissible'  => (bool) $config['dismissible'],
            'show_to'      => $config['show_to'],
            'link_url'     => $config['link_url'],
            'link_label'   => $config['link_label'],
            // Text style
            'font_size'    => $config['font_size'] ?? '13',
            'font_bold'    => (bool) ($config['font_bold'] ?? false),
            'font_italic'  => (bool) ($config['font_italic'] ?? false),
            'font_underline' => (bool) ($config['font_underline'] ?? false),
            'font_color'   => $config['font_color'] ?? ''
        ]);
        $response->setTitle(_('Message of the Day'));
        $this->setResponse($response);
    }
}
